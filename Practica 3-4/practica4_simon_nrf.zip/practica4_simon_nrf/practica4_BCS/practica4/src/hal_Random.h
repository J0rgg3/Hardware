#ifndef HAL_RANDOM_H
#define HAL_RANDOM_H

#include <stdint.h>
#include <stdlib.h>


void hal_random_iniciar(uint32_t semilla);

uint32_t hal_random_generar(uint32_t min,uint32_t max);

#endif /* HAL_random_H */
