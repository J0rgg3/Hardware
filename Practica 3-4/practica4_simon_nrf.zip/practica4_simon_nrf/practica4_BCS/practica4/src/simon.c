#include <stdint.h>
#include "rt_evento_t.h"
#include "simon.h"
#include "hal_random.h"
#include "svc_alarma.h"
#include "drv_leds.h"
#include "drv_tiempo.h"
#include "rt_GE.h"
#include "hal_WDT.h"

#define TIMEOUT 5000 // Tiempo maximo para contestar
#define TIEMPO_ENTRE_NIVEL 2 //Tiempo de espera entre pasar un nivel y empezar el siguente
#define AUMENTO_DIFICULTAD 400 // Ms que se van a ir restando a los retardos para aumentar la dificultad
#define DIFICULTAD_MAX 500

static _GameState estado; // Estado inicial
static uint32_t nivel; //Indica el  nivel en el que esta el usuario y la longuitud de la secuncia de leds
static uint32_t retardo_entreLed; //India el tiempo que pasa entre que se apaga un led y se enciende el siguiente
static uint32_t retardo_apagado; //Indica el tiempo que pasa un led encendido 

static uint32_t secuencia[100]; // Secuencia de leds en orden
static uint32_t index;	// Numero que representa el lugar del led actual dentro del vector del 
static uint32_t acertados; // Numero de botones que se han acertado en el input

static uint32_t num_botones;
static uint32_t num_leds;
	
void simon_iniciar(uint32_t leds,uint32_t botones){
	
	num_leds = leds;
	num_botones = botones;
	estado = e_INIT;
	hal_WDT_iniciar(1);
	hal_random_iniciar(1);
	//Suscribir tareas
	svc_GE_suscribir(ev_LED,simon_tratar);
	svc_GE_suscribir(ev_PULSAR_BOTON,simon_tratar);
	svc_GE_suscribir(ev_TIMEOUT,simon_tratar);
	svc_GE_suscribir(ev_RESULTADO,simon_tratar);
	
	//Inicia el juego
	svc_alarma_activar(svc_alarma_codificar(0,50),ev_RESULTADO,0);
	
	rt_GE_lanzador();
	
}
/*
	
*/
void simon_aviso_succes(){

	drv_led_encender(1);
	drv_led_encender(3);

}

/*
	
*/
void simon_aviso_fail(){

	drv_led_encender(0);
}

void simon_aviso_iniciar(){
	drv_led_apagar(0);
	drv_led_encender(0);

}

void simon_tratar(uint32_t evento,uint32_t auxiliar){

	switch(estado){
		
		case e_INIT:
			
			//AVISO DE INICIO
			simon_aviso_iniciar();
			
			//VARIABLES GENERALES
				index = 0;
				acertados = 0;
				nivel = 1;
				secuencia[0] = hal_random_generar(1,num_botones);//Genera un numero del 1 al 4 que representar� el led a encnder
			
			//RETARDOS
				retardo_apagado = 3000;
				retardo_entreLed = 2000;
			
			//TRANSICION AL SIGUIENTE ESTADO
				estado = e_SHOW_SEQUENCE;
				svc_alarma_activar(svc_alarma_codificar(0,50) ,ev_LED,0);
			
		
			 break;
		case e_SHOW_SEQUENCE:
			
		switch(evento){
			case ev_LED:
				
				
					if(auxiliar == 0){//si el axuliar es 0 se enciende el led
						drv_led_apagar(0);
						drv_led_encender(secuencia[index]);
						svc_alarma_activar(svc_alarma_codificar(0,retardo_apagado) ,ev_LED,1);
						
					}else{//si el axuliar es 1 se apaga el led
						drv_led_apagar(secuencia[index]);
						index++;
						if(index < nivel){
							svc_alarma_activar(svc_alarma_codificar(0,retardo_entreLed) ,ev_LED,0);
					
						}else{
							estado = e_WAIT_FOR_INPUT;
							index = 0; //Se reseta index
							acertados = 0;
							svc_alarma_activar(svc_alarma_codificar(0,TIMEOUT),ev_TIMEOUT,auxiliar);//Se porgrama la alarma en caso de no contestar a tiempo
						}
						
					}	
						
					
					break;
			
		}
			break;
		case e_WAIT_FOR_INPUT:
			//Comprobar input que acaba de entrar(ev_puldarBoton), si corresponde con el led que toca
			switch(evento){
				case ev_PULSAR_BOTON:
					
						if(auxiliar +1 == secuencia[index]){//Comprueba si el boton pulsado corresponde con el led correcto
								acertados++; //Suma un acierto
								index++; //avanza al siguiente led de la secuencia
								if(acertados == nivel){
									
									estado = e_SUCCESS;
									svc_alarma_activar(svc_alarma_codificar(0,0),ev_TIMEOUT,auxiliar);//Se desactiva la alarma
									svc_alarma_activar(svc_alarma_codificar(0,30),ev_RESULTADO,auxiliar);
								}else{
									svc_alarma_activar(svc_alarma_codificar(0,TIMEOUT),ev_TIMEOUT,auxiliar);//Se porgrama la alarma en caso de no contestar a tiempo
								}
								
						}else{
							estado = e_FAIL;
							svc_alarma_activar(svc_alarma_codificar(0,0),ev_TIMEOUT,auxiliar);
							svc_alarma_activar(svc_alarma_codificar(0,50),ev_RESULTADO,auxiliar);
							
						}
						
						break;
				
				case ev_TIMEOUT:
					//Caso en que no le de a tiempo a algun boton
					
					estado = e_FAIL;
					svc_alarma_activar(svc_alarma_codificar(0,30),ev_RESULTADO,auxiliar);
					break;
			}
		
			break;
		case e_SUCCESS:
			switch(evento){
				case ev_RESULTADO:
				//AVISO DE ACIERTO
				simon_aviso_succes();
			
				//AUMENTO DE DIFIFULTAD
				if(retardo_apagado > DIFICULTAD_MAX){
					retardo_apagado = 	retardo_apagado - AUMENTO_DIFICULTAD;
				}
				if(retardo_entreLed > DIFICULTAD_MAX){
					retardo_entreLed =	retardo_entreLed - AUMENTO_DIFICULTAD;
				}
					
				secuencia[nivel] = hal_random_generar(1,num_botones);//Genera un numero del 1 al 4 que representar� el led a encnder
				nivel++;
				index = 0;
			
				//TRANSICI�N DE ESTADO
				estado = e_SHOW_SEQUENCE;
				svc_alarma_activar(svc_alarma_codificar(0,1000),ev_LED,0 );
				break;
			}
			break;
		case e_FAIL:
			switch(evento){
				case ev_RESULTADO:
				//AVISO DE FALLO
					simon_aviso_fail();
				//TRANSICI�N DE ESTADO
					estado = e_INIT;
					
				break;
			}
		break;
	}
}
