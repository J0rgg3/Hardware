#ifndef RT_GE_H
#define RT_GE_H

#include <stdint.h>
#include "rt_evento_t.h"

// M�ximo de tareas suscritas a cada evento
#define rt_GE_MAX_SUSCRITOS 4

typedef void (*CallbackFunc)();


// Estructura de suscripci�n
typedef struct {
    EVENTO_T ID_evento;
    CallbackFunc Tareas [rt_GE_MAX_SUSCRITOS];	//Vector de funciones que tiene que hacer cada evento 
		int numTareas;	//Indice que muestra el n�mero de tareas para el evento
} Suscripcion;

void rt_GE_iniciar(uint32_t monitor);
void rt_GE_lanzador(void);
void svc_GE_suscribir(EVENTO_T evento, CallbackFunc f_callback);
void svc_GE_cancelar(EVENTO_T evento, CallbackFunc f_callback);
void rt_GE_tratar(EVENTO_T evento, uint32_t auxiliar);

#endif // RT_GE_H
