
#ifndef HAL_EXT_INT_H
#define HAL_EXT_INT_H

#include <stdint.h>

// Inicializa el módulo de interrupciones externas y configura el callback
void hal_ext_int_iniciar( void(*funcionCallback)());

void hal_ext_int_iniciar_boton(uint32_t botton,uint32_t pin);

void hal_ext_int_habilitar(uint32_t pin);

void hal_ext_int_deshabilitar(uint32_t pin);

void hal_ext_int_habilitar_despertar(uint32_t pin);

void hal_ext_int_deshabilitar_despertar(uint32_t pin);

uint32_t hal_ext_int_comprobar_pulsado(uint32_t pin);



#endif // HAL_EXT_INT_H
