#ifndef HAL_WDT_H
#define HAL_WDT_H

#include <stdint.h>

// Definiciones para el tiempo de timeout en segundos


// Prototipos de funciones

/* Inicializa el watchdog con un timeout especificado
*/
void hal_WDT_iniciar(uint32_t sec);   

/* Recarga el watchdog para evitar el timeout
*/
void hal_WDT_feed(void);                     

#endif 
