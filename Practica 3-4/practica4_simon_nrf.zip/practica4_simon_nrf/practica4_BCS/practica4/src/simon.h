#ifndef SIMON_H
#define SIMON_H

#include <stdint.h>

	typedef enum {
		e_INIT,
		e_SHOW_SEQUENCE,
		e_WAIT_FOR_INPUT,
		e_SUCCESS,
		e_FAIL
	} _GameState;

	void simon_iniciar( uint32_t leds,uint32_t num_botones);
		
	void simon_tratar(uint32_t evento,uint32_t auxiliar);
	
#endif
	