/* *****************************************************************************
  * P.H.2024: Driver/Manejador de los Leds
	*
	* blink practica 2 de proyecto hardware 2024
 */
 
#include <stdint.h>
#include <stdbool.h>

#include "hal_gpio.h"
#include "drv_leds.h"
#include "drv_tiempo.h"
#include "drv_consumo.h"
#include "drv_monitor.h"
#include "rt_evento_t.h"
#include "rt_fifo.h"
#include "hal_ext_int.h"
#include "rt_GE.h"
#include "svc_alarma.h"
#include "drv_botones.h"
#include "hal_WDT.h"
#include "simon.h"

#define RETARDO_MS 500 		//retardo blink en milisegundos
#define BUTTON_DESPERTAR_NRF 25 //Boton para despertar el blink_v3_bis en nrf
#define BUTTON_DESPERTAR_LPC 14	//Boton para despertar el blink_v3_bis en lpc
#define DISMINUCION_RETARDOS 50	//Ms que se van restando en el bit counter strike a los retardos para aumentar la dificultad
/*Variables staticas*/
static uint32_t num_leds;	//Numero de Leds del hardware
static uint32_t num_botones;//Numerp de botones del hardware
static uint32_t num_Monitors; //Numerod de monitores del hardware

//Bit Counter Strike
static uint32_t led_actual; 		//Indice que nos indica en que led esta el juego
static uint32_t timeout_botones;//Tiempo maximo que tiene el usuario para pulsar el boton correspondiente
static uint32_t espera_leds_ms;	//Espera entre que se apaga y enciende un led	en bit count strike



void leds_dormir(uint32_t id, uint32_t ms){
	
	drv_led_apagar(0);
}

/* *****************************************************************************
 * BLINK, parpadeo de un led conmutando on/off 
 * retardo por bucle de instrucciones, solo usa el manejador del led
 * para realizar la primera sesi�n de la practica
 */
void blink_v1(uint32_t id){
  while (1) {
    uint32_t volatile tmo;
    
    tmo = 10000000;
    while (tmo--);
    drv_led_conmutar(id);     
	}		
}

/* *****************************************************************************
 * BLINK, parpadeo de un led conmutando on/off 
 * activacion por tiempo, usa tanto manejador del led como el del tiempo
 * para realizar en la segunda sesi�n de la practica, version a entregar
 */
void  blink_v2(uint32_t id){
	Tiempo_ms_t siguiente_activacion;	
	
	drv_led_encender(id);

	siguiente_activacion = drv_tiempo_actual_ms();
	
	/* Toggle LEDs. */
	while (true) {
		siguiente_activacion += RETARDO_MS; //ms
		drv_tiempo_esperar_hasta_ms(siguiente_activacion);
		drv_led_conmutar(id);
		//otras cosas
	}
}


//------------Blinkv3-------------------
/*
 * Función de callback que llama a la función led_conmutar. 
*/
void leds_c(uint32_t id, uint32_t ms){

	drv_led_conmutar(id);
}

/* *****************************************************************************
 * BLINK, parpadeo de un led conmutando on/off 
 * activación periódica, CPU a la espera (dormida) y poca actividad,
 * usa tanto manejador del led como el del tiempo
 */
void  blink_v3(uint32_t id){
	//drv_consumo_iniciar();
	
	drv_led_encender(id);
	drv_tiempo_periodico_ms(RETARDO_MS,leds_c,id);
	
	while(1) {
		 drv_consumo_esperar();

	}
}


void blink_v3_bis(uint32_t num_Leds){
	drv_botones_iniciar(rt_FIFO_encolar,ev_PULSAR_BOTON,ev_BOTON_RETARDO);
	drv_led_encender(0);// Enciende todos los leds
	drv_consumo_iniciar(4,3);
	
	drv_tiempo_periodico_ms(RETARDO_MS,leds_c,num_Leds);
	int num_palpitaciones = 0;
	
	while(num_palpitaciones < 20) {
			drv_consumo_esperar();
			num_palpitaciones++;

	}
	//Apaga todos los leds
	drv_led_apagar(0);//	Apaga todos los leds
	
	//Duerme profundo
	
	drv_consumo_dormir();
	
}

//------------Blinkv4-------------------

/*
 * Función de callback que llama a la función rt_FIFO_encolar. 
*/
void encolar(uint32_t id, uint32_t ms){
	
	rt_FIFO_encolar(id,ms);
}


/* *****************************************************************************
 * BLINK, parpadeo de un led conmutando on/off 
 * activación por runtime, CPU a la espera (dormida) y poca actividad,
 * usa tanto manejador del led como el del tiempo
 */
void blink_v4(uint32_t id) {
	
	EVENTO_T EV_ID_evento;
	uint32_t EV_auxData,EV_TS;
	
	rt_FIFO_inicializar(id);
	drv_led_encender(id);
	drv_tiempo_periodico_ms(RETARDO_MS, rt_FIFO_encolar, ev_T_PERIODICO);
	
	while (1) {
		if (rt_FIFO_extraer(&EV_ID_evento, & EV_auxData, & EV_TS)) {
			if (ev_T_PERIODICO) {
				drv_led_conmutar(id); 
			}
		}
		else {
			drv_consumo_esperar(); 
		}
	}
}
//-------------------------------------Pruebas practica 4-------------------------------------------
void leds_encenderTodos(uint32_t id, uint32_t ms);

void leds_apagarTodos(uint32_t id, uint32_t ms){
	svc_GE_suscribir((EVENTO_T) id,leds_encenderTodos);
	drv_led_apagar(0);
	svc_GE_cancelar((EVENTO_T)id,leds_apagarTodos);
}

void leds_encenderTodos(uint32_t id, uint32_t ms){
	svc_GE_suscribir((EVENTO_T)id,leds_apagarTodos);
	drv_led_encender(0);
	svc_GE_cancelar((EVENTO_T)id,leds_encenderTodos);
			
}
/*
 * Funcion que simula una prueba sencilla para el gestor de evento y la alarma
 * se basa en suscribir una tarea al evento periodico y otra al evento void(usamosa este para evitar las funciones "tratar")
 * y se lanza una alram periodica del void, cuando el evenot void hace sus tareas, se le quita la de "encenderTodos" y se le pone "apagarTodos"
 * y asi indefinidamente
	*/

void TestAlarmaGestorEvento(){
	
	//suscribir tareas
	svc_GE_suscribir(ev_T_PERIODICO,leds_c);
	svc_GE_suscribir(ev_VOID,leds_encenderTodos);
	svc_alarma_activar(svc_alarma_codificar(1,1000),ev_VOID,0);
	rt_GE_lanzador();

}
/*
*	Funcion que comprueba el funcionamiento de los botones junto al gestor y alarmas.
*	Se basa en lo mismo que la anterior solo que ahora el evento void es un evento pulsar boton
*/
void TestBotones(){

	svc_GE_suscribir(ev_T_PERIODICO,leds_c);
	svc_GE_suscribir(ev_PULSAR_BOTON,leds_encenderTodos);
	//svc_alarma_activar(svc_alarma_codificar(1,1000),ev_PULSAR_BOTON,0);
	rt_GE_lanzador();
	
}
/*
 *  Prueba si se ha configurado correctamente la gestion de overflow de las alarmas
 */
void TestOverflowAlarmas(){
	
	svc_alarma_activar(svc_alarma_codificar(0,1000),ev_VOID,1); 
	svc_alarma_activar(svc_alarma_codificar(0,1000),ev_LED,1); 
	svc_alarma_activar(svc_alarma_codificar(0,1000),ev_BOTON_RETARDO,1); 
	svc_alarma_activar(svc_alarma_codificar(0,1000),ev_INACTIVIDAD,1); 
	svc_alarma_activar(svc_alarma_codificar(0,1000),ev_PULSAR_BOTON,1); 

}

/*
 *  Prueba si se ha configurado correctamente la gestion de overflow del gestor de eventos
 */
void TestOverflowGE(){
	svc_GE_suscribir(ev_VOID,leds_c);
	svc_GE_suscribir(ev_VOID,leds_c);
	svc_GE_suscribir(ev_VOID,leds_c);
	svc_GE_suscribir(ev_VOID,leds_c);
	svc_GE_suscribir(ev_VOID,leds_c);
}
/*
 *  Prueba si el watchdog resetea el sistema y se le alimenta correctamente
 */

void TestWatchdog(){
	hal_WDT_iniciar(5);
	svc_GE_suscribir(ev_T_PERIODICO,leds_encenderTodos);
 // while(1);
	rt_GE_lanzador();
	
}

//-------------------------Bit counter strike-------------------------------------------
void secuencia_leds2(uint32_t id, uint32_t ms){
	
	
		drv_led_apagar(led_actual);	//Apaga el led actual
	
	
		if(led_actual == num_leds || led_actual == num_botones){//garantiza que el número del LED actual se incremente y vuelva al inicio (1) después de llegar al último LED o BOTON.
			led_actual = 1;
			
		}else{
			led_actual ++;
		}
		drv_led_encender(led_actual);//enciende el siguiente led
		
	svc_alarma_activar(svc_alarma_codificar(0, timeout_botones), ev_LED, drv_tiempo_actual_ms());
	
}
/*
	función que gestiona la secuencia del counter strike
	"Ir encendiendo leds (secuencia, array,…)"
*/
void secuencia_leds(uint32_t id, uint32_t ms){
	
	if(ms == 1){//Enciende el led y programa la alarma de timeout
		
		drv_led_encender(led_actual);//enciende el siguiente led

		svc_alarma_activar(svc_alarma_codificar(0,timeout_botones),ev_LED,0);//"Usuario tiene un tiempo para pulsar botón correspondiente"

	}else{//Apaga el led y programa la alarma para enceder el siguiente
		drv_led_apagar(led_actual);	//Apaga el led actual
			
		
		if(led_actual == num_leds || led_actual == num_botones){//garantiza que el número del LED actual se incremente y vuelva al inicio (1) después de llegar al último LED o BOTON.
			led_actual = 1;
			
		}else{
			led_actual ++;
		}
		svc_alarma_activar(svc_alarma_codificar(0,espera_leds_ms),ev_LED,1); // espera entre apagado y encendido del led
	}
	
}
/*
	función que gestiona como actua el sistema al pulsar un boton en el juego counter strike
	Se encarga de comprobar si se ha pulsado el boton correcto, si es asi "aumenta la dificultad" y llama a la funcion que hace
	continuar la secuencia de leds
*/

void pulsar_boton_cs(uint32_t id, uint32_t button){
	
	if(button+1 == led_actual) {
		//Aumento de dificultad
		timeout_botones -= DISMINUCION_RETARDOS; //Se va disminuyendo el tiempo de cambio entre los botones para aumnetar la dificultad
		espera_leds_ms -= DISMINUCION_RETARDOS;
		//Aumento de dificultad
		secuencia_leds2(id,0);
	}
}

void bitCounterStrike(){
	
	//Inicializar 
	//hal_WDT_iniciar(5);
	espera_leds_ms = 500;	//espera inicial en 500 ms
	timeout_botones = 4000;	//
	led_actual = 1;
	
	//Suscribir
	svc_GE_suscribir(ev_PULSAR_BOTON,pulsar_boton_cs);
	svc_GE_suscribir(ev_LED,secuencia_leds2);
	
	//ajustes inicio de juego
	 secuencia_leds2(0, 1);
	
	rt_GE_lanzador();

}

/* *****************************************************************************
 * MAIN, Programa principal.
 * para la primera sesion se debe usar la funcion de blink_v1 sin temporizadores
 * para la entrega final se debe incocar a blink_v2
 */
 int main(void){
	
//INICIALIZACIÓN HARDWARE
	/* Init tiempo, es un reloj que indica el tiempo desde que comenzo la ejecuci�n */
	drv_tiempo_iniciar(); // para la sesion 2 de practica 2, es necesario iniciarlo para blinkv3, para valor HAL_TICKS2US
	
	hal_gpio_iniciar();	// llamamos a iniciar gpio antesde que lo hagan los drivers
	 
	drv_consumo_iniciar(3,4);
	rt_FIFO_inicializar(5);
	rt_GE_iniciar(1);
	svc_GE_suscribir(ev_INACTIVIDAD,leds_dormir);
	svc_alarma_iniciar(2,rt_FIFO_encolar, ev_T_PERIODICO);
	
	/* Configure LED*/
		num_leds = drv_leds_iniciar();
	/* Configure Monitor*/
		num_Monitors = drv_monitor_iniciar();
	/* Configure Botones*/
		num_botones = drv_botones_iniciar(rt_FIFO_encolar,ev_PULSAR_BOTON,ev_BOTON_RETARDO);
	 


	
	
//		
	
	
//	if (Num_Leds > 0){
//		
////		drv_led_encender(1);
////		blink_v1(1);			
////		blink_v2(2);			
////		blink_v3(3);
////		if (Num_Monitors > 0) {
////			blink_v4(4);
////		}
//	}
	//blink_v3_bis(3);

//TEST
	//TestAlarmaGestorEvento();
	//TestBotones();
	//TestOverflowAlarmas();
	//TestWatchdog();
	bitCounterStrike();
	//simon_iniciar(num_leds,num_botones);
	
	
}
