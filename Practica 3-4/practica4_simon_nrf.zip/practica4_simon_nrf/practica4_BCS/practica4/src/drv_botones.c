	// drv_botones.c
#include "drv_botones.h"
#include "rt_evento_t.h"
#include "rt_fifo.h"
#include "rt_GE.h"
#include "svc_alarma.h"
#include "hal_gpio.h"
#include "hal_ext_int.h"
#include "drv_tiempo.h"
#include "board.h"

// Estado actual de la máquina de estados
static Estado_boton estado_actual; // Estado inicial

// Callback del botón que se ejecuta al detectar una pulsación
static void (*drv_cb)(uint32_t, uint32_t);
#if BUTTONS_NUMBER > 0
	static const uint8_t button_list[BUTTONS_NUMBER] = BUTTON_LIST;
#endif



void drv_botones_cb(uint32_t pin){
		
		drv_cb(ev_PULSAR_BOTON,pin);
}

// Función para iniciar el módulo de botones
uint32_t drv_botones_iniciar( void(*f_callback)(uint32_t, uint32_t),EVENTO_T botonPulsar,EVENTO_T botonRetardo) {
			
	drv_cb = f_callback;
	
	hal_ext_int_iniciar(drv_botones_cb);//Incializa el modulo ext_int
	
	for(int i = 0; i < BUTTONS_NUMBER; i++){
		
		hal_gpio_sentido(button_list[i],HAL_GPIO_PIN_DIR_INPUT);
		
		hal_ext_int_iniciar_boton(button_list[i],i);
		
		
	}
		estado_actual = e_reposo;
    // Suscribirse al evento de pulsación de botón
    svc_GE_suscribir(botonPulsar, drv_botones_tratar);
	  svc_GE_suscribir(botonRetardo, drv_botones_tratar);
	
	return BUTTONS_NUMBER;

}

// Función de manejo de eventos de botón
void drv_botones_tratar(EVENTO_T evento, uint32_t auxData) {//Auxdata == id boton
    switch (estado_actual) {
        case e_reposo:
            if (evento == ev_PULSAR_BOTON) {
                // Cambiar al estado e_entrando
								estado_actual = e_entrando;

								// callback para encolar ID_ev y auxdata
								//drv_cb(ev_BOTON_RETARDO, auxData);

								// Activar alarma de retardo Trp y generar el evento ev_BOTON_RETARDO
								svc_alarma_activar(svc_alarma_codificar(0,30), ev_BOTON_RETARDO, auxData);
            }
            break;
        case e_entrando:
            if (evento == ev_BOTON_RETARDO) {
                // Cambiar al estado e_esperando
			
							estado_actual = e_esperando;
							svc_alarma_activar(svc_alarma_codificar(1,50), ev_BOTON_RETARDO, auxData);
							
            }
            break;
        case e_esperando:
            if (evento == ev_BOTON_RETARDO) {
								// Verificar si el botón sigue presionado o no
								if (!hal_ext_int_comprobar_pulsado(button_list[auxData])) {
										// Cambiar al estado e_soltado
										estado_actual = e_soltado;
										// Activar alarma de retardo Trd y generar el evento ev_BOTON_RETARDO
										svc_alarma_activar(svc_alarma_codificar(0,10), ev_BOTON_RETARDO, auxData);
								} 
            }
            break;
        case e_soltado:
             
                // Reiniciar al estado e_reposo
								estado_actual = e_reposo;

								// Habilitar interrupciones externas para el botón
								hal_ext_int_habilitar(auxData);
								
				
            break;
        default:
            break;
    }
		

}

