#include "rt_GE.h"
#include "rt_fifo.h"
#include "rt_evento_t.h"
#include "drv_tiempo.h"
#include "drv_consumo.h"
#include <stdbool.h>
#include "svc_alarma.h"
#include "drv_monitor.h"
#include <stdint.h>
#include "hal_WDT.h"


static Suscripcion suscripciones[EVENT_TYPES];
static uint8_t num_suscripciones;//Indice del vector de suscripciones
static uint32_t monitor_overflow;


// Inicializa las estructuras y alarma de inactividad
void rt_GE_iniciar(uint32_t monitor) {
    //Inicializacion
		monitor_overflow = monitor;
	for(int i = 0; i < EVENT_TYPES; i++){
		suscripciones[i].ID_evento = i;
	} 
		// Iniciar el Watchdog Timer con un timeout de 5 segundos
    //hal_WDT_iniciar(5);
	
	num_suscripciones = EVENT_TYPES;
	
	
		
		svc_GE_suscribir(ev_PULSAR_BOTON,rt_GE_tratar); //Suscibes la tarea tratar del ge al evento de pulsar boton
}

// Revisa la cola de eventos y los despacha
void rt_GE_lanzador(void) {
			
	EVENTO_T ID_evento;
	uint32_t auxData;
	uint32_t TS;
	svc_GE_suscribir(ev_INACTIVIDAD, rt_GE_tratar); //Suscibes la tarea tratar del ge al evento de inactividad
	svc_alarma_activar(svc_alarma_codificar(0,20*1000),ev_INACTIVIDAD,0); // activa alarma ev_INACTIVIDAD 
	
	while (1) {
        // Extrae evento de la cola y despacha a las tareas suscritas
        if (rt_FIFO_extraer(&ID_evento, &auxData, &TS)) {
            for (int i = 0; i < num_suscripciones; i++) {
                if (suscripciones[i].ID_evento == ID_evento) {
									//enviar el evento y el campo auxiliar a todas las tareas suscritas a ese evento.
									for(int j=0; j < suscripciones[i].numTareas;j++){
										
										suscripciones[i].Tareas[j](ID_evento,auxData);
										
									}
                    break;
               }
            }
        }else {
            // Si no hay eventos, poner en espera para ahorrar energ�a
            drv_consumo_esperar();
        }
    }
}

// Suscribe una tarea a un evento (maneja overflow)
void svc_GE_suscribir(EVENTO_T evento, CallbackFunc f_callback) {
		
		for(int i = 0; i <num_suscripciones; i++){
			if( suscripciones[i].ID_evento == evento){
				
					if (suscripciones[i].numTareas >= rt_GE_MAX_SUSCRITOS) {
						// Manejo de overflow, bucle infinito
						drv_monitor_marcar(monitor_overflow);//Enciende el monitor
						while (1);
						
					}else{
						
						suscripciones[i].Tareas[suscripciones[i].numTareas] = f_callback;
						suscripciones[i].numTareas++;
						
						break;
						
					}
			}
			
		}
		
   
}

// Cancela una suscripci�n a un evento y compacta
void svc_GE_cancelar(EVENTO_T evento, CallbackFunc f_callback) {
		int encontrada = 0;
    for (int i = 0; i < num_suscripciones; i++) {
			//Busca el evento al que quiere cancelarle una tarea
        if (suscripciones[i].ID_evento == evento) {
					//Busca la tarea a desuscribir
					for (int j = 0; j < suscripciones[i].numTareas; j++) {
                if(suscripciones[i].Tareas[j] == f_callback){
									encontrada = 1;								//Ha encontrado la tarea a cancelar
									suscripciones[i].numTareas--;	//Resta la tarea cancelada
								}
								if(encontrada){
									if(j != suscripciones[i].numTareas ){
												suscripciones[i].Tareas[j] = suscripciones[i].Tareas[j+1]; // Compacta el vector de tareas
									 
									}
								}
            }
            break;
        }
    }
}

// Gestiona el tratamiento de eventos seg�n el tipo
void rt_GE_tratar(EVENTO_T evento, uint32_t auxiliar) {
    
		switch (evento) {
    case ev_PULSAR_BOTON:
				// Reprogramar la alarma de inactividad
				// funcion para activar botones
				svc_alarma_activar(svc_alarma_codificar(0,20*1000),ev_INACTIVIDAD,0);
		
        break;
    case ev_INACTIVIDAD:
				// Activar modo de suspensi�n profunda o bajo consumo
        // Implementar suspensi�n o reinicio seg�n el sistema
         drv_consumo_dormir();
        break;
    default:
        // C�digo para cualquier otro caso
        break;
	}
 
     
      
}
