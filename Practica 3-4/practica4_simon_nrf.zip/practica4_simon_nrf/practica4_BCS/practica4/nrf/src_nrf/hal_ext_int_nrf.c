#include "hal_ext_int.h"
#include "nrf.h"  
#include "rt_evento_t.h"


/*
	El id del boton representa como se tratan los botones a lo largo del programa, desde este modulo hasta el main.
	En nuestro caso, se hara referencia al "boton 1" de la placa con el id 0 que a su vez es el canal en el que esperar� eventos y asi sucesivamente.
	Esto es relevante a la hora de tratar los botones para entender a cual se esta haciendo refrencia
	canal 0 --> boton 1 --> id del boton = 0
	canal 1 --> boton 2 --> id del boton = 1
	canal 2 --> boton 3 --> id del boton = 2
	canal 3 --> boton 4 --> id del boton = 3

*/
void (*f_callback)();
void GPIOTE_IRQHandler(void);

/*
 * Inicialzia el modulo, con ello habilita la IRQ del Gpiote y guarda funci�n de callback
 * 
 */

void hal_ext_int_iniciar(void(*funcionCallback)()){

 	f_callback = funcionCallback;

	
	NVIC_EnableIRQ(GPIOTE_IRQn);//Habilita la IRQ del GPIOTE


}
/*
 * Inicialzia el boton pasado por paramtero "botton" en el canal pasado por parametro "�pin"
 * 
 */

void hal_ext_int_iniciar_boton(uint32_t botton,uint32_t canal){
	
		NRF_GPIO->PIN_CNF[botton] =(GPIO_PIN_CNF_PULL_Pullup << GPIO_PIN_CNF_PULL_Pos) |
													 (GPIO_PIN_CNF_INPUT_Connect << GPIO_PIN_CNF_INPUT_Pos) |
													 (GPIO_PIN_CNF_SENSE_Disabled << GPIO_PIN_CNF_SENSE_Pos) |
														(GPIO_PIN_CNF_DRIVE_S0S1 << GPIO_PIN_CNF_DRIVE_Pos);
														
		NRF_GPIO->PIN_CNF[botton] |= (GPIO_PIN_CNF_SENSE_Low << GPIO_PIN_CNF_INPUT_Pos);
		// Configurar GPIOTE para detecci�n de flancos
		NRF_GPIOTE->CONFIG[canal] = (GPIOTE_CONFIG_MODE_Event << GPIOTE_CONFIG_MODE_Pos) |
														(GPIOTE_CONFIG_POLARITY_Toggle << GPIOTE_CONFIG_POLARITY_Pos) |
														(botton << GPIOTE_CONFIG_PSEL_Pos);

		NRF_GPIOTE->EVENTS_IN[canal] = 0;//Se limpian eventos por si acaso hay pendientes
	
		NRF_GPIOTE->INTENSET = (1 << canal);//Habilita el canal correspiendete del 0-3

}

/*
 * Habilita las interrupciones del gpiote en el canal que se pase por parametro como "canal" 
 * y limpia los eventos pendientes
 */
void hal_ext_int_habilitar(uint32_t canal){
	//Pin -1 porque como parametro se le pasa el numero del boton[1-4]
	if (NRF_GPIOTE->EVENTS_IN[canal]) {//Comprueba si quedan interrupciones pendientes
			
			NRF_GPIOTE->EVENTS_IN[canal] = 0;//Si hay, las limpia
	}
	//Habilitar especifica
	//NRF_GPIOTE->INTENSET = (1 << canal);//Habilita la interrupcion en el canal correspondiente
	
	//Habilitar todas(siempre hay que limpiar antes)
	NRF_GPIOTE->INTENSET = 15;//Habilita el canal correspiendete del 0-3

}

/*
 * Deshabilita las interrupciones del gpiote en el canal que se pase por parametro como "canal" 
 * 
 */
void hal_ext_int_deshabilitar(uint32_t canal){
	
	
	//Desactiva la interrupcion de este canal
	//NRF_GPIOTE->INTENCLR = (1 << canal);
	
	//deshabilitar todas
	NRF_GPIOTE->INTENCLR = 15;

}

/*
 * Comprueba si el boton relacionado con el canal del parametro "canal" sigue pulsado
 * Esto se hace; limpiando las interrupciones pendientes del canal correspondiente y, posteriormnete comprobando si 
 * sigue habiendo interrupciones activas en ese canal.
 */

uint32_t hal_ext_int_comprobar_pulsado(uint32_t boton){
		
// Version inspirada por el lpc	
//		if (NRF_GPIOTE->EVENTS_IN[canal]) {//Comprueba si quedan interrupciones pendientes
//			
//			NRF_GPIOTE->EVENTS_IN[canal] = 0;//Si hay, las limpia
//		}
//	
//		return NRF_GPIOTE->EVENTS_IN[canal];//Devulve el valor del canal 1 si hay interrupciones(pulsado) 0 si no hay(no pulsado)
	
		return ((NRF_GPIO->IN & (1 << boton)) == 0); 
	// El registro IN refleja en tiempo real el estado l�gico actual (alto o bajo) de todos los pines GPIO configurados como entradas.
	// Si el boton no esta pulsado tendr� un 1 en la direccion que corresponde al boton dentro del pin
}



/*
 * Funcion  IRQ que maneja las interrupciones del GPIOTE para cada cana
 *
 */

void  GPIOTE_IRQHandler(void) {
	
	if (NRF_GPIOTE->EVENTS_IN[0]) {//Evento en el canal 0
		hal_ext_int_deshabilitar(0);
		NRF_GPIOTE->EVENTS_IN[0] = 0;//	Limpia eventos en el canal 0 
		f_callback(0); //Llama a la funcion calback(drv_botones_cb)
		
	}else if (NRF_GPIOTE->EVENTS_IN[1]) {//Evento en el canal 1
		hal_ext_int_deshabilitar(1);
		NRF_GPIOTE->EVENTS_IN[1] = 0;//	Limpia eventos en el canal 1
		f_callback(1);
		
	} else if (NRF_GPIOTE->EVENTS_IN[2]) {//Evento en el canal 2
		hal_ext_int_deshabilitar(2);
		NRF_GPIOTE->EVENTS_IN[2] = 0;//	Limpia eventos en el canal 2
		f_callback(2);
		
	}else if (NRF_GPIOTE->EVENTS_IN[3]) {//Evento en el canal 3
		hal_ext_int_deshabilitar(3);
		NRF_GPIOTE->EVENTS_IN[3] = 0;//	Limpia eventos en el canal 3
		f_callback(3);

	}

}

