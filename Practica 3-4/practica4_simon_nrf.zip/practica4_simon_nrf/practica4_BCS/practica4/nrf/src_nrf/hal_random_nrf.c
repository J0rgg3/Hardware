#include <stdint.h>
#include <stdlib.h>
#include "hal_random.h"
#include <nrf.h>


void hal_random_iniciar(uint32_t semilla){

		NRF_RNG -> TASKS_START = 1; // Inicia el generador 
		
}

uint32_t hal_random_generar(uint32_t min,uint32_t max){


	return (NRF_RNG->VALUE % max) + min;
}
