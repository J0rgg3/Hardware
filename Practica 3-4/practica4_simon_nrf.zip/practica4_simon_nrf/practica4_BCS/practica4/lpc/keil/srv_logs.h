// Definir los niveles de log
#define LOG_LEVEL_DEBUG 3
#define LOG_LEVEL_INFO 2
#define LOG_LEVEL_ERROR 1
#define LOG_LEVEL_NONE 0
#define ENDLINE "\r\n"
// Configurar el nivel de log actual
#define LOG_LEVEL LOG_LEVEL_DEBUG
// Macros para log seg�n nivel depuraci�n configurado

#if LOG_LEVEL >= LOG_LEVEL_DEBUG
	#define LOG_DEBUG(msg) drv_uart_send("DEBUG: " msg "\r\n")
#else
	#define LOG_DEBUG(msg) // Macro vac�a
#endif

#if LOG_LEVEL >= LOG_LEVEL_INFO
	#define LOG_INFO(msg) drv_uart_send("INFO: " msg "\r\n")
#endif