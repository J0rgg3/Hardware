#include <stdint.h>
#include <stdlib.h>
#include "hal_random.h"


void hal_random_iniciar(uint32_t semilla){

		srand(semilla);

}

uint32_t hal_random_generar(uint32_t min,uint32_t max){

	return (rand() % max) + min;
}
